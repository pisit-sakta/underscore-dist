const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-BBCE3jTL.js","assets/index-Dvux0MoU.js","assets/index-BCbktdRd.css"])))=>i.map(i=>d[i]);
import{r as p,_ as r}from"./index-Dvux0MoU.js";const _=p("App",{web:()=>r(()=>import("./web-BBCE3jTL.js"),__vite__mapDeps([0,1,2])).then(e=>new e.AppWeb)});export{_ as App};
