const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-BKWVJyLq.js","assets/index-Byl_NebX.js","assets/index-D9AVFRbW.css"])))=>i.map(i=>d[i]);
import{r as p,_ as r}from"./index-Byl_NebX.js";const _=p("App",{web:()=>r(()=>import("./web-BKWVJyLq.js"),__vite__mapDeps([0,1,2])).then(e=>new e.AppWeb)});export{_ as App};
