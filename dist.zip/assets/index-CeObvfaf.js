const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-D-W0_iVh.js","assets/index-BYzf8wzP.js","assets/index-Dn4HJtIp.css"])))=>i.map(i=>d[i]);
import{r as p,_ as r}from"./index-BYzf8wzP.js";const _=p("App",{web:()=>r(()=>import("./web-D-W0_iVh.js"),__vite__mapDeps([0,1,2])).then(e=>new e.AppWeb)});export{_ as App};
