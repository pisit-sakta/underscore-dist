const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-BGA4D6MW.js","assets/index-CnFCu49a.js","assets/index-D9AVFRbW.css"])))=>i.map(i=>d[i]);
import{r as p,_ as r}from"./index-CnFCu49a.js";const _=p("App",{web:()=>r(()=>import("./web-BGA4D6MW.js"),__vite__mapDeps([0,1,2])).then(e=>new e.AppWeb)});export{_ as App};
