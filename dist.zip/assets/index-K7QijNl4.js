const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-F_Zarldx.js","assets/index-CuXLy_Ph.js","assets/index-DeJyxeDh.css"])))=>i.map(i=>d[i]);
import{r as p,_ as r}from"./index-CuXLy_Ph.js";const _=p("App",{web:()=>r(()=>import("./web-F_Zarldx.js"),__vite__mapDeps([0,1,2])).then(e=>new e.AppWeb)});export{_ as App};
